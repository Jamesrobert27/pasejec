


// 
$('.counter-number').counterUp({
    delay: 80,
    time: 1500
});
